from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import sqlite3, os, time
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), 'ladle.db')
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS sightings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ladle_id TEXT,
        ocr_conf REAL,
        track_id TEXT,
        camera_id TEXT,
        zone TEXT,
        bbox TEXT,
        timestamp TEXT
    )
    ''')
    conn.commit()
    conn.close()

init_db()

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/edge/event', methods=['POST'])
def ingest_event():
    data = request.get_json()
    if not data:
        return jsonify({'status':'error','message':'no json'}), 400
    # minimal validation
    ladle_id = data.get('ladle_id') or 'UNKNOWN'
    ocr_conf = float(data.get('ocr_conf') or 0.0)
    track_id = data.get('track_id') or ''
    camera_id = data.get('camera_id') or ''
    zone = data.get('zone') or ''
    bbox = str(data.get('bbox') or '')
    ts = data.get('timestamp') or datetime.utcnow().isoformat()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO sightings (ladle_id, ocr_conf, track_id, camera_id, zone, bbox, timestamp) VALUES (?,?,?,?,?,?,?)',
              (ladle_id, ocr_conf, track_id, camera_id, zone, bbox, ts))
    conn.commit()
    conn.close()
    return jsonify({'status':'ok'})

@app.route('/api/livestatus', methods=['GET'])
def live_status():
    # return latest sighting per ladle_id within last 24h
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
    SELECT ladle_id, MAX(timestamp) as last_seen, camera_id, zone, ocr_conf
    FROM sightings
    GROUP BY ladle_id
    ORDER BY last_seen DESC
    LIMIT 200
    ''')
    rows = c.fetchall()
    conn.close()
    results = []
    for r in rows:
        results.append({
            'ladle_id': r[0],
            'last_seen': r[1],
            'camera_id': r[2],
            'zone': r[3],
            'ocr_conf': r[4]
        })
    return jsonify(results)

@app.route('/api/history/<ladle_id>', methods=['GET'])
def history(ladle_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT timestamp, camera_id, zone, ocr_conf FROM sightings WHERE ladle_id=? ORDER BY timestamp DESC LIMIT 500', (ladle_id,))
    rows = c.fetchall()
    conn.close()
    return jsonify([{'timestamp':r[0],'camera_id':r[1],'zone':r[2],'ocr_conf':r[3]} for r in rows])

# static files
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(os.path.join(app.root_path, 'static'), filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
