# edge_client.py
# Simulates an edge node posting ladle sightings to server every few seconds.
import requests, time, random, uuid
SERVER = 'http://localhost:5000/api/edge/event'

LADDLES = ['LD1001','LD1002','LD1003','LD200A','LD9X8']
CAMERAS = ['CAM-A','CAM-B','CAM-C']
ZONES = ['TLC_PIT','CONVERTER','LADLE_PREP','LF-1','CASTER']

def make_msg():
    ladle = random.choice(LADDLES)
    data = {
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'camera_id': random.choice(CAMERAS),
        'track_id': str(uuid.uuid4())[:8],
        'ladle_id': ladle,
        'ocr_conf': round(random.uniform(0.4, 0.99), 2),
        'zone': random.choice(ZONES),
        'bbox': [random.randint(0,1000) for _ in range(4)]
    }
    return data

if __name__ == '__main__':
    print('Starting edge simulator. Posting to', SERVER)
    try:
        while True:
            msg = make_msg()
            try:
                r = requests.post(SERVER, json=msg, timeout=2)
                print('sent', msg['ladle_id'], '->', r.status_code)
            except Exception as e:
                print('post failed', e)
            time.sleep(random.uniform(1.0, 3.0))
    except KeyboardInterrupt:
        print('Stopped simulator')
