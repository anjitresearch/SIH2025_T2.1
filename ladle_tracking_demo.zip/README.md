# Ladle Tracking Demo (Hackathon)
Minimal prototype for "Hot metal and Steel Ladle Tracking" (Problem ID: 25187).

Components:
- server/: Flask server that ingests edge events and serves a simple dashboard.
- edge_client.py: Simulated edge client that posts random ladle sightings to server.
- docker-compose.yml: Compose file to run the server (optional).
- requirements.txt: Python dependencies.

Quick start (local, requires Python 3.8+):
1. Create virtualenv: `python -m venv venv && source venv/bin/activate`
2. Install: `pip install -r requirements.txt`
3. Run server: `python server/app.py`
4. In another terminal run simulator: `python edge_client.py`
5. Open dashboard: http://localhost:5000

Notes:
- This is an MVP demo: OCR/detection parts are simulated. Replace edge_client with your edge inference node to POST real metadata.
- The server stores sightings in SQLite (`server/ladle.db`) and exposes APIs.
